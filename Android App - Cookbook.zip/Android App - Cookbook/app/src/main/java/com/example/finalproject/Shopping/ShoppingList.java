package com.example.finalproject.Shopping;

import android.content.Context;
import android.content.SharedPreferences;

public class ShoppingList {

   long id,fks_id;
    String sName,sList,sDate;

    public ShoppingList(String sName, String sList, String sDate, long id,long fks_id)
    {
        this.sName=sName;
        this.sList=sList;
        this.sDate=sDate;
        this.id=id;
        this.fks_id=fks_id;
    }

    public long getFks_id() {
        return fks_id;
    }

    public void setFks_id(long fks_id) {
        this.fks_id = fks_id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getsDate() {
        return sDate;
    }

    public void setsDate(String sDate) {
        this.sDate = sDate;
    }

    public String getsName() {
        return sName;
    }

    public void setsName(String sName) {
        this.sName = sName;
    }

    public String getsList() {
        return sList;
    }

    public void setsList(String sList) {
        this.sList = sList;
    }

}
