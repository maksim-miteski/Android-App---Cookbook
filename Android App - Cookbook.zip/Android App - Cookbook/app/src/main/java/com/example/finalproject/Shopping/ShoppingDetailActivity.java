package com.example.finalproject.Shopping;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.finalproject.Activities.MainActivity;
import com.example.finalproject.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class ShoppingDetailActivity extends AppCompatActivity {

    long id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_detail);

        BottomNavigationView bottomNavigationView=(BottomNavigationView)findViewById(R.id.bottom);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.home_bottom:
                        Intent intent=new Intent(ShoppingDetailActivity.this, MainActivity.class);
                        startActivity(intent);
                        break;
                }
            }
        });

        getIncomingIntent();
    }
    private void getIncomingIntent(){
        if(getIntent().hasExtra("id") && getIntent().hasExtra("name") && getIntent().hasExtra("shopping_list") && getIntent().hasExtra("date")){

            id=getIntent().getExtras().getLong("id");
            String shoppingName=getIntent().getStringExtra("name");
            String shoppingList=getIntent().getStringExtra("shopping_list");
            String date=getIntent().getStringExtra("date");


            setRecipeText(id,shoppingName,shoppingList,date);
        }
    }

    private void setRecipeText(long id,String shoppingName,String shoppingList,String date) {

        TextView name = (TextView) findViewById(R.id.setShoppingName);
        name.setText(shoppingName);

        TextView list = (TextView) findViewById(R.id.setShoppingList);
        list.setText(shoppingList);

        TextView dateSet = (TextView) findViewById(R.id.tv_display_date);
        dateSet.setText(date);

    }

    public void deleteList(View view) {
        ShoppingListActivity.mDatabaseHelper.deleteDataList(id);
        startActivity(new Intent(ShoppingDetailActivity.this, ShoppingListActivity.class));
        finish();
    }
}