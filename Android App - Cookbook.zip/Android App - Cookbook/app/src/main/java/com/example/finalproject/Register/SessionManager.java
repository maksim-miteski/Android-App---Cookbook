package com.example.finalproject.Register;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;


    public SessionManager(Context context){
        sharedPreferences=context.getSharedPreferences("AppKey",Context.MODE_PRIVATE);
        editor=sharedPreferences.edit();
    }

    public void setLogin(boolean login){
        editor.putBoolean("KEY_LOGIN",login);
        editor.commit();
    }

    public boolean getLogin(){
        return sharedPreferences.getBoolean("KEY_LOGIN", false);
    }

    public void saveSession(User user){
        long id=user.getId();
        editor.putLong("USER_ID",id).commit();
    }

    public long getAuthUserId(){
        return sharedPreferences.getLong("USER_ID",-1);
    }

    public void removeAuthUserId(){
        editor.putLong("USER_ID",-1).commit();
    }

    public void setUsername(String username){
        editor.putString("KEY_USERNAME",username);
        editor.commit();
    }

    public String getUsername(){
        return sharedPreferences.getString("KEY_USERNAME", "");
    }

    public void setuName(String name){
        editor.putString("KEY_NAME",name);
        editor.commit();
    }

    public String getuName(){
        return sharedPreferences.getString("KEY_NAME", "");
    }

    public void setAge(String age){
        editor.putString("KEY_AGE",age);
        editor.commit();
    }

    public String getAge(){
        return sharedPreferences.getString("KEY_AGE", "");
    }

}
