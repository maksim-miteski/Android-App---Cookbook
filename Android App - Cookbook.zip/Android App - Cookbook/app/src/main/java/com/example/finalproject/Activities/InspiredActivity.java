package com.example.finalproject.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.finalproject.R;
import com.example.finalproject.Recipes.AddNewActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class InspiredActivity extends AppCompatActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inspired);

        Button desertButton=(Button)findViewById(R.id.desertButton);
        Button bakingButton=(Button)findViewById(R.id.bakingButton);
        Button drinksButton=(Button)findViewById(R.id.drinksButton);
        Button piesButton=(Button)findViewById(R.id.piesButton);
        Button soupsButton=(Button)findViewById(R.id.soupsButton);
        Button cakesButton=(Button)findViewById(R.id.cakesButton);
        Button pastaButton=(Button)findViewById(R.id.pastaButton);
        Button saladsButton=(Button)findViewById(R.id.saladsButton);
        Button specialDietButton=(Button)findViewById(R.id.spdietButton);

        ImageButton pinterestButton=(ImageButton)findViewById(R.id.pinterestButton);
        ImageButton instagramButton=(ImageButton)findViewById(R.id.instagramButton);
        ImageButton facebookButton=(ImageButton)findViewById(R.id.facebookButton);

        BottomNavigationView bottomNavigationView=(BottomNavigationView)findViewById(R.id.bottom);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
               switch(item.getItemId()){
                   case R.id.home_bottom:
                      Intent intent=new Intent(InspiredActivity.this, MainActivity.class);
                      startActivity(intent);
                       break;
               }
            }
        });

    }

   public void onClickOpenWebpageButton(View v) {
        switch (v.getId()) {
            case R.id.desertButton:
                String urlStringDesert="https://www.delish.com/cooking/recipe-ideas/g3246/easy-desserts/";
                openWebPage(urlStringDesert);
                break;
            case R.id.bakingButton:
                String urlStringBaking="https://www.tasteofhome.com/collection/grandma-s-best-baking-recipes/";
                openWebPage(urlStringBaking);
                break;
            case R.id.drinksButton:
                String urlStringDrinks="https://www.allrecipes.com/recipes/77/drinks/";
                openWebPage(urlStringDrinks);
                break;
            case R.id.piesButton:
                String urlStringPies="https://www.foodnetwork.com/recipes/articles/50-pie-recipes";
                openWebPage(urlStringPies);
                break;
            case R.id.soupsButton:
                String urlStringSoups="https://themodernproper.com/30-best-soup-recipes";
                openWebPage(urlStringSoups);
                break;
            case R.id.cakesButton:
                String urlStringCakes="https://www.bbcgoodfood.com/recipes/collection/classic-cake-recipes";
                openWebPage(urlStringCakes);
                break;
            case R.id.pastaButton:
                String urlStringPasta="https://www.delish.com/cooking/recipe-ideas/g3176/weeknight-pasta-dinners/";
                openWebPage(urlStringPasta);
                break;
            case R.id.saladsButton:
                String urlStringSalads="https://www.loveandlemons.com/salad-recipes/";
                openWebPage(urlStringSalads);
                break;
            case R.id.spdietButton:
                String urlStringDiet="https://www.eatingwell.com/recipes/18045/weight-loss-diet/";
                openWebPage(urlStringDiet);
                break;

                //social media buttons:
            case R.id.pinterestButton:
                String urlStringPinterest="https://www.pinterest.com/";
                openWebPage(urlStringPinterest);
                break;
            case R.id.instagramButton:
                String urlStringInstagram="https://www.instagram.com/";
                openWebPage(urlStringInstagram);
                break;
            case R.id.facebookButton:
                String urlStringFacebook="https://www.facebook.com/";
                openWebPage(urlStringFacebook);
                break;
        }
    }

    private void openWebPage(String url){
        Uri webPage = Uri.parse(url);
        Intent intent=new Intent(Intent.ACTION_VIEW, webPage);
            startActivity(intent);
    }
}