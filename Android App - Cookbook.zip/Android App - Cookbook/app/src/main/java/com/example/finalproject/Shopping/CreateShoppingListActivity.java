package com.example.finalproject.Shopping;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.finalproject.Activities.MainActivity;
import com.example.finalproject.Database.DatabaseHelper;
import com.example.finalproject.R;
import com.example.finalproject.Recipes.AddNewActivity;
import com.example.finalproject.Register.SessionManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Calendar;

public class CreateShoppingListActivity extends AppCompatActivity {

    long id;
    Button saveList;
    EditText editName,editBody;
    DatabaseHelper mDatabaseHelper;
    TextView chooseDate, setDate;
    SessionManager sessionManager;

    private DatePickerDialog.OnDateSetListener mDateSetListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_shopping_list);
        sessionManager=new SessionManager(CreateShoppingListActivity.this);

        editName=(EditText)findViewById(R.id.ed_shopping_name);
        editBody=(EditText)findViewById(R.id.ed_shopping_body);
        saveList=(Button)findViewById(R.id.btn_save_list);

        mDatabaseHelper=new DatabaseHelper(this);

        chooseDate=(TextView)findViewById(R.id.chooseDay);
        setDate=(TextView) findViewById(R.id.setDay);

        setDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal=Calendar.getInstance();
                int year=cal.get(Calendar.YEAR);
                int month=cal.get(Calendar.MONDAY);
                int day=cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog=new DatePickerDialog(CreateShoppingListActivity.this,
                        android.R.style.Widget_Holo,
                        mDateSetListener, year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                dialog.show();
            }
        });
        mDateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month=month+1;
                String date=month + "/" + dayOfMonth + "/" + year;
                setDate.setText(date);
            }
        };

        saveList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameEntry=editName.getText().toString();
                String listEntry=editBody.getText().toString();
                String dateEntry=setDate.getText().toString();
                long fks_userid=sessionManager.getAuthUserId();

                AddShoppingData(nameEntry,listEntry,dateEntry,id,fks_userid);
                Intent intent=new Intent(CreateShoppingListActivity.this, ShoppingListActivity.class);
                startActivity(intent);
            }
        });

        BottomNavigationView bottomNavigationView=(BottomNavigationView)findViewById(R.id.bottom);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.home_bottom:
                        Intent intent=new Intent(CreateShoppingListActivity.this, MainActivity.class);
                        startActivity(intent);
                        break;
                }
            }
        });

    }
    public void AddShoppingData(String name, String list,String date,long id,long fks_id){

        boolean insertData=mDatabaseHelper.addShoppingData(name,list,date,id,fks_id);
        if(insertData == true){
            toastMessage("Data has been successfully inserted!");
        }else{
            toastMessage("Something went wrong!");
        }
    }
    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }

    public void openReminder(View view){
        Intent intent=new Intent(CreateShoppingListActivity.this, ReminderActivity.class);
        startActivity(intent);
    }
}