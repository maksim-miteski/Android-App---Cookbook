package com.example.finalproject.Recipes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.finalproject.R;

public class EditActivity extends AppCompatActivity {

    long id;
    EditText name,type,ingredients,body,recipeAllergens,recipeDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        id=getIntent().getExtras().getLong("id");

        String incomingName=getIntent().getExtras().getString("name");
        name = (EditText) findViewById(R.id.edit_name);
        name.setText(incomingName);

        String incomingType=getIntent().getExtras().getString("type");
        type = (EditText) findViewById(R.id.edit_type);
        type.setText(incomingType);

        String incomingIngredients=getIntent().getExtras().getString("ingredients");
        ingredients = (EditText) findViewById(R.id.edit_ingredients);
        ingredients.setText(incomingIngredients);

        String incomingBody=getIntent().getExtras().getString("body");
        body = (EditText) findViewById(R.id.edit_recipe);
        body.setText(incomingBody);

        String incomingAllergens=getIntent().getExtras().getString("allergens");
        recipeAllergens = (EditText) findViewById(R.id.edit_allergens);
        recipeAllergens.setText(incomingAllergens);

        String incomingDate=getIntent().getExtras().getString("date");
        recipeDate = (EditText) findViewById(R.id.edit_date);
        recipeDate.setText(incomingDate);
    }

    public void updateRecipe(View view) {
        String updateName=name.getText().toString();
        String updateType=type.getText().toString();
        String updateIngredients=ingredients.getText().toString();
        String updateBody=body.getText().toString();
        String updateAllergens=recipeAllergens.getText().toString();
        String updateDate=recipeDate.getText().toString();

        DetailActivity.mDatabaseHelper.editRecipe(id,updateName,updateType,updateIngredients,updateBody,updateAllergens,updateDate);
        startActivity(new Intent(EditActivity.this, RecipeActivity.class));
    }

    public void cancelEditing(View view) {
        Intent intent=new Intent(EditActivity.this, RecipeActivity.class);
        startActivity(intent);
    }
}
