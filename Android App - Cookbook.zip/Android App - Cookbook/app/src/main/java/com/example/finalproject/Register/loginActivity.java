package com.example.finalproject.Register;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.finalproject.Activities.HomeFragment;
import com.example.finalproject.Activities.InspiredActivity;
import com.example.finalproject.Activities.MainActivity;
import com.example.finalproject.Database.DatabaseHelper;
import com.example.finalproject.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class loginActivity extends AppCompatActivity {


    EditText etUsername, etPassword;
    DatabaseHelper mDatabaseHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername=(EditText)findViewById(R.id.et_username);
        etPassword=(EditText)findViewById(R.id.et_password);
        mDatabaseHelper=new DatabaseHelper(this);

        BottomNavigationView bottomNavigationView=(BottomNavigationView)findViewById(R.id.bottom);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.home_bottom:
                        Intent intent=new Intent(loginActivity.this, MainActivity.class);
                        startActivity(intent);
                        break;
                    case R.id.register_bottom:
                        Intent intent2=new Intent(loginActivity.this, RegisterActivity.class);
                        startActivity(intent2);
                        break;
                }
            }
        });
    }

    public void loginUser(View view) {
       String username=etUsername.getText().toString();
       String password=etPassword.getText().toString();

       SessionManager sessionManager=new SessionManager(loginActivity.this);
       if(username.equals("") || password.equals("")) {
            Toast.makeText(loginActivity.this, "All Fields are Required!", Toast.LENGTH_SHORT).show();
            String fieldsRequired = "This field is Required!";
            etUsername.setError(fieldsRequired);
            etPassword.setError(fieldsRequired);
        }else{
           User user=mDatabaseHelper.getUserByUserId(username);

            mDatabaseHelper.validateUser(username,password);

            if(mDatabaseHelper.validateUser(username, password)==true){
                sessionManager.setLogin(true);
                sessionManager.setUsername(username);

                String name=sessionManager.getuName();
                String age=sessionManager.getAge();

                sessionManager.setuName(name);
                sessionManager.setAge(age);
                sessionManager.saveSession(user);

                Toast.makeText(loginActivity.this, "Sign In successful!", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(loginActivity.this, MainActivity.class);
                startActivity(intent);

            }else{
                Toast.makeText(loginActivity.this, "Invalid username and password", Toast.LENGTH_SHORT).show();
                if(mDatabaseHelper.validateUser(username, password)==false) {
                    String invalidUsername = "Invalid Username or Password";
                    etUsername.setError(invalidUsername);
                }
            }
        }
    }
}