package com.example.finalproject.Register;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.finalproject.Activities.HomeFragment;
import com.example.finalproject.Activities.InspiredActivity;
import com.example.finalproject.Activities.MainActivity;
import com.example.finalproject.Database.DatabaseHelper;
import com.example.finalproject.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class RegisterActivity extends AppCompatActivity{

      EditText etUsername,etName,etAge, etPassword, rePassword;
      DatabaseHelper mDatabaseHelper;
      SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etUsername=(EditText)findViewById(R.id.editt_username);
//        etName=(EditText)findViewById(R.id.edit_name);
//        etAge=(EditText)findViewById(R.id.edit_age);
        etPassword=(EditText)findViewById(R.id.et_password);
        rePassword=(EditText)findViewById(R.id.et_repassword);
        mDatabaseHelper=new DatabaseHelper(this);
        sessionManager=new SessionManager(getApplicationContext());

        BottomNavigationView bottomNavigationView=(BottomNavigationView)findViewById(R.id.bottom);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.home_bottom:
                        Intent intent=new Intent(RegisterActivity.this, MainActivity.class);
                        startActivity(intent);
                        break;
                    case R.id.login_bottom:
                        Intent intent2=new Intent(RegisterActivity.this, loginActivity.class);
                        startActivity(intent2);
                        break;
                }
            }
        });
    }

    public void registerUser(View view) {
        String username=etUsername.getText().toString();
//        String name=etName.getText().toString();
//        String age=etAge.getText().toString();
        String password=etPassword.getText().toString();
        String rePass=rePassword.getText().toString();

        if(username.equals("") || password.equals("") || rePass.equals(""))
        {
            Toast.makeText(RegisterActivity.this, "All Fields are Required!", Toast.LENGTH_SHORT).show();
            String fieldsRequired="This field is required!";
            etUsername.setError(fieldsRequired);
//            etName.setError(fieldsRequired);
//            etAge.setError(fieldsRequired);
            etPassword.setError(fieldsRequired);
            rePassword.setError(fieldsRequired);
        }
        else{

            if(password.equals(rePass)) {
                Boolean checkUser = mDatabaseHelper.checkUserName(username);

                if(password.length() < 7){
                    String shortPassword="Password Must be at least 7 characters long!";
                    etPassword.setError(shortPassword);
                }
               else if (checkUser == false)
                {
                    Boolean insert = mDatabaseHelper.addUserData(username,password);
                    sessionManager.setUsername(username);
//                    sessionManager.setuName(name);
//                    sessionManager.setAge(age);

                    if (insert == true)
                    {
                        Toast.makeText(RegisterActivity.this, "Registered successfully!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(RegisterActivity.this, loginActivity.class);
                        startActivity(intent);
                    }
                    else
                        {
                        Toast.makeText(RegisterActivity.this, "Registration Failed!", Toast.LENGTH_SHORT).show();
                        }
                }
                else
                    {
                    Toast.makeText(RegisterActivity.this, "User already exists! Please sign In!", Toast.LENGTH_SHORT).show();
                    String userExists="User already exists! Please sign In!";
                    etUsername.setError(userExists);
                    }
            }
            else
                {
                Toast.makeText(RegisterActivity.this, "Passwords are not Matching", Toast.LENGTH_SHORT).show();
                String passNotMatching="Passwords are not matching!";
                rePassword.setError(passNotMatching);
                }
        }
    }
}