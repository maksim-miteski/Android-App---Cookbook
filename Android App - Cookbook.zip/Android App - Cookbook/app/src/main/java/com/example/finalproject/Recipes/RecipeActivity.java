package com.example.finalproject.Recipes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.Toast;

import com.example.finalproject.Activities.InspiredActivity;
import com.example.finalproject.Activities.MainActivity;
import com.example.finalproject.Database.DatabaseHelper;
import com.example.finalproject.R;
import com.example.finalproject.Register.SessionManager;
import com.example.finalproject.Register.User;
import com.example.finalproject.Register.loginActivity;
import com.example.finalproject.Register.userProfile;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class RecipeActivity extends AppCompatActivity{


    RecyclerView recipesRecyclerList;
    static DatabaseHelper mDatabaseHelper;
    ArrayList<Recipe> arrayList;
    RecyclerView.LayoutManager layoutManager;
    RecipeRecyclerAdapter recipeAdapter;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);
        sessionManager=new SessionManager(RecipeActivity.this);

//                if(sessionManager.getSession()!=-1) {
//                    recipesRecyclerList = (RecyclerView) findViewById(R.id.recycler_view);
//                    mDatabaseHelper = new DatabaseHelper(this);
//                    arrayList = mDatabaseHelper.getData();
//                    recipesRecyclerList.setHasFixedSize(true);
//                    layoutManager = new LinearLayoutManager(this);
//                    recipesRecyclerList.setLayoutManager(layoutManager);
//                    recipeAdapter = new RecipeRecyclerAdapter(this, arrayList, recipesRecyclerList);
//                    recipesRecyclerList.setAdapter(recipeAdapter);
//                }
//                if(sessionManager.getSession()==-1){
//                    onStop();
//                }

        BottomNavigationView bottomNavigationView=(BottomNavigationView)findViewById(R.id.bottom);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.home_bottom:
                        Intent intent=new Intent(RecipeActivity.this, MainActivity.class);
                        startActivity(intent);
                        break;
                }
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        arrayList.clear();
        recipesRecyclerList.removeAllViews();
        recipeAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onPause() {
        super.onPause();
        arrayList.clear();
        recipesRecyclerList.removeAllViews();
        recipeAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
            recipesRecyclerList = (RecyclerView) findViewById(R.id.recycler_view);
            mDatabaseHelper = new DatabaseHelper(this);
            arrayList = mDatabaseHelper.getRecipesByUserID(sessionManager.getAuthUserId());
            recipesRecyclerList.setHasFixedSize(true);
            layoutManager = new LinearLayoutManager(this);
            recipesRecyclerList.setLayoutManager(layoutManager);
            recipeAdapter = new RecipeRecyclerAdapter(this, arrayList, recipesRecyclerList);
            recipesRecyclerList.setAdapter(recipeAdapter);
    }

    private void layoutAnimation(RecyclerView recyclerView){
        Context context=recyclerView.getContext();
        LayoutAnimationController layoutAnimationController=
        AnimationUtils.loadLayoutAnimation(context, R.anim.layout_fall_down);
        recyclerView.setLayoutAnimation(layoutAnimationController);
        recyclerView.getAdapter().notifyDataSetChanged();
        recyclerView.scheduleLayoutAnimation();
    }
}
