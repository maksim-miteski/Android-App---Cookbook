package com.example.finalproject.Database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.finalproject.Recipes.Recipe;
import com.example.finalproject.Register.SessionManager;
import com.example.finalproject.Register.User;
import com.example.finalproject.Shopping.ShoppingList;

import java.util.ArrayList;
import java.util.List;


public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "cookbook_database";

    //*******************RECIPES TABLE*************************
    private static final String TABLE_RECIPES = "recipe_table";
    private static final String COL0 = "recipe_id";
    private static final String COL1 = "recipe_name";
    private static final String COL2 = "recipe_type";
    private static final String COL3 = "recipe_ingredients";
    private static final String COL4 = "recipe_body";
    private static final String COL5 = "allergens";
    private static final String COL6 = "date";
    private static final String FK_USER = "fk_user_id";


    //********************SHOPPING LIST TABLE*******************
    private static final String TABLE_SHOPPING = "shopping_table";
    private static final String COLID = "list_id";
    private static final String COLNAME = "list_name";
    private static final String COLLIST = "list_body";
    private static final String DATE = "listDate";
    private static final String SFK_USER = "fk_user_id";

    //********************REGISTER TABLE *************************
    private static final String TABLE_USER = "user_table";
    private static final String USERID = "user_id";
    private static final String USERNAME = "username";
    private static final String NAME = "name";
    private static final String AGE = "age";
    private static final String PASSWORD = "password";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
       //**********RECIPES TABLE************
        String createTable1 = "CREATE TABLE " + TABLE_RECIPES + "  (" + COL0 + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL1 + " TEXT, " + COL2 +
                " TEXT, " + COL3 + " TEXT, " + COL4 + " TEXT, " + COL5 +  " TEXT, "+ COL6 + " TEXT, "+
                FK_USER + " INTEGER NOT NULL, " + " FOREIGN KEY ("+FK_USER+") REFERENCES "+TABLE_USER+"("+USERID+")"+ " )"; //BLOB
        db.execSQL(createTable1);

        //*********SHOPPING TABLE**********
        String createTable2 = "CREATE TABLE " + TABLE_SHOPPING + "  (" + COLID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLNAME + " TEXT, " + COLLIST + " TEXT,  "+ DATE + " TEXT, " +
                SFK_USER + " INTEGER NOT NULL, " + " FOREIGN KEY ("+SFK_USER+") REFERENCES "+TABLE_USER+"( "+USERID+")" +" )";
        db.execSQL(createTable2);

        //***********USER TABLE***********
        String createTable3 = "CREATE TABLE " + TABLE_USER + "  (" + USERID + " INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " + USERNAME + " TEXT, " + NAME +" TEXT, " +AGE + " TEXT, " + PASSWORD + " TEXT " +" )";
        db.execSQL(createTable3);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RECIPES);
        onCreate(db);

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SHOPPING);
        onCreate(db);

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        onCreate(db);
    }

    public boolean addData(String name, String type, String ingredients, String body, String allergens, String date, long id, long fk_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, name);
        contentValues.put(COL2, type);
        contentValues.put(COL3, ingredients);
        contentValues.put(COL4, body);
        contentValues.put(COL5, allergens);
        contentValues.put(COL6, date);
        contentValues.put(FK_USER, fk_id);

        id = db.insert(TABLE_RECIPES, null, contentValues);
        if (id == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean addShoppingData(String name, String shopping_list,String date,long id,long fks_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        //contentValues.put(COLID, id);
        contentValues.put(COLNAME, name);
        contentValues.put(COLLIST, shopping_list);
        contentValues.put(DATE, date);
        contentValues.put(SFK_USER, fks_id);

        id = db.insert(TABLE_SHOPPING, null, contentValues);
        if (id == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean addUserData(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USERNAME, username);
//        contentValues.put(NAME, name);
//        contentValues.put(AGE, age);
        contentValues.put(PASSWORD, password);

        long id2 = db.insert(TABLE_USER, null, contentValues);
        if (id2 == -1) {
            return false;
        } else {
            return true;
        }
    }

    public User getUserByUserId(String userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query="SELECT * FROM " + TABLE_USER + " WHERE " + USERNAME + " = ? ";
        String[] whereArgs = {userId};
        Cursor cursor = db.rawQuery(query, whereArgs);
        User user = null;

        if (cursor.moveToFirst()) {
            user = new User(cursor.getString(cursor.getColumnIndex(USERID)), cursor.getString(cursor.getColumnIndex(PASSWORD)),
                    Long.parseLong(cursor.getString(cursor.getColumnIndex(USERID))));
        }
        cursor.close();
        db.close();
        return user;
    }

    public boolean validateUser(String username,String password){
        String query="SELECT * FROM "+ TABLE_USER + " WHERE " + USERNAME + " = ? AND " + PASSWORD + " = ? " ;
        String[] whereArgs = {username,password};
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, whereArgs);
        int count = cursor.getCount();

        cursor.close();

        return count >= 1;
    }

    public boolean checkUserName(String username)
    {
        String query="SELECT * FROM "+ TABLE_USER + " WHERE " + USERNAME + " = ? ";
        String[] whereArgs = {username};
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, whereArgs);

        int count = cursor.getCount();

        cursor.close();
        return count >= 1;
    }

    public ArrayList<Recipe> getRecipesByUserID(long userid) {
        ArrayList<Recipe> arrayList = new ArrayList<>();

        String sql="SELECT * FROM " + TABLE_RECIPES + " AS r " + " INNER JOIN " + TABLE_USER + " AS u "
                + " ON r." + FK_USER + " = u." + USERID + " WHERE r." + FK_USER + " = " + userid;

           Cursor cursor=getReadableDatabase().rawQuery(sql,null);
              for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
                  long id = cursor.getLong(0);
                  String name = cursor.getString(1);
                  String type = cursor.getString(2);
                  String ingredients = cursor.getString(3);
                  String body = cursor.getString(4);
                  String allergens = cursor.getString(5);
                  String date = cursor.getString(6);
                  long fk_userid = cursor.getLong(7);

                  Recipe recipe = new Recipe(name, type, ingredients, body, allergens, date, id, fk_userid);
                  arrayList.add(recipe);
              }
              cursor.close();
        return arrayList;
    }

    public ArrayList<ShoppingList> getShoppingDataByUserId(long userid) {
        ArrayList<ShoppingList> arrayList = new ArrayList<>();

        String sql="SELECT * FROM " + TABLE_SHOPPING + " AS s " + " INNER JOIN " + TABLE_USER + " AS u "
                + " ON s." + SFK_USER + " = u." + USERID + " WHERE s." + SFK_USER + " = " + userid;

        Cursor cursor=getReadableDatabase().rawQuery(sql,null);
        //while (cursor.moveToNext()) {
        for(cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
            long id= cursor.getLong(0);
            String name = cursor.getString(1);
            String shopping_list = cursor.getString(2);
            String date = cursor.getString(3);
            long fks_userid=cursor.getLong(4);

            ShoppingList shoppingList = new ShoppingList(name, shopping_list,date,id,fks_userid);
            arrayList.add(shoppingList);
        }
        return arrayList;
    }

    public int deleteDataNew(long id) {
            SQLiteDatabase db = getWritableDatabase();
            String whereArgs[]={""+id};
            int count=db.delete(TABLE_RECIPES, COL0 + "=?", whereArgs);
            return count;
    }

    public int deleteDataList(long id) {
        SQLiteDatabase db = getWritableDatabase();
        String whereArgs[]={""+id};
        int count=db.delete(TABLE_SHOPPING,COLID + "=?", whereArgs);
        return count;
    }

    public int editRecipe(long id,String name,String type, String ingredients,String recipe, String allergens,String date) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        //contentValues.put(COL0, id);
        contentValues.put(DatabaseHelper.COL1, name);
        contentValues.put(COL2, type);
        contentValues.put(COL3, ingredients);
        contentValues.put(COL4, recipe);
        contentValues.put(COL5, allergens);
        contentValues.put(COL6, date);

        String whereArgs[]={""+id};
        int count=db.update(DatabaseHelper.TABLE_RECIPES, contentValues, DatabaseHelper.COL0 + "=?",whereArgs);
        return count;
    }
}
