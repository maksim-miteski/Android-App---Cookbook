package com.example.finalproject.Shopping;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;

import com.example.finalproject.Activities.MainActivity;
import com.example.finalproject.Database.DatabaseHelper;
import com.example.finalproject.R;
import com.example.finalproject.Recipes.RecipeActivity;
import com.example.finalproject.Recipes.RecipeRecyclerAdapter;
import com.example.finalproject.Register.SessionManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class ShoppingListActivity extends AppCompatActivity {

    RecyclerView shoppingRecyclerList;
    static DatabaseHelper mDatabaseHelper;
    ArrayList<ShoppingList> arrayList;
    RecyclerView.LayoutManager layoutManager;
    ShoppingRecyclerAdapter shoppingAdapter;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_list);
        sessionManager=new SessionManager(ShoppingListActivity.this);


//        shoppingRecyclerList = (RecyclerView) findViewById(R.id.recycler_view_shopping);
//        mDatabaseHelper=new DatabaseHelper(this);
//        arrayList=mDatabaseHelper.getShoppingData();
//        shoppingRecyclerList.setHasFixedSize(true);
//        layoutManager=new LinearLayoutManager(this);
//        shoppingRecyclerList.setLayoutManager(layoutManager);
//        shoppingAdapter=new ShoppingRecyclerAdapter(this, arrayList, shoppingRecyclerList);
//        shoppingRecyclerList.setAdapter(shoppingAdapter);

        BottomNavigationView bottomNavigationView=(BottomNavigationView)findViewById(R.id.bottom);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.home_bottom:
                        Intent intent=new Intent(ShoppingListActivity.this, MainActivity.class);
                        startActivity(intent);
                        break;
                }
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        arrayList.clear();
        shoppingRecyclerList.removeAllViews();
        shoppingAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onPause() {
        super.onPause();
        arrayList.clear();
        shoppingRecyclerList.removeAllViews();
        shoppingAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
        shoppingRecyclerList = (RecyclerView) findViewById(R.id.recycler_view_shopping);
        mDatabaseHelper=new DatabaseHelper(this);
        arrayList=mDatabaseHelper.getShoppingDataByUserId(sessionManager.getAuthUserId());
        shoppingRecyclerList.setHasFixedSize(true);
        layoutManager=new LinearLayoutManager(this);
        shoppingRecyclerList.setLayoutManager(layoutManager);
        shoppingAdapter=new ShoppingRecyclerAdapter(this, arrayList, shoppingRecyclerList);
        shoppingRecyclerList.setAdapter(shoppingAdapter);
    }


    private void layoutAnimation(RecyclerView recyclerView){
        Context context=recyclerView.getContext();
        LayoutAnimationController layoutAnimationController=
                AnimationUtils.loadLayoutAnimation(context, R.anim.layout_fall_down);
        recyclerView.setLayoutAnimation(layoutAnimationController);
        recyclerView.getAdapter().notifyDataSetChanged();
        recyclerView.scheduleLayoutAnimation();
    }
}