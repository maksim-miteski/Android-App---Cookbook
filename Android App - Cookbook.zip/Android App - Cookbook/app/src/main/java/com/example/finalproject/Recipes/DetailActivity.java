package com.example.finalproject.Recipes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.finalproject.Activities.MainActivity;
import com.example.finalproject.Database.DatabaseHelper;
import com.example.finalproject.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class DetailActivity extends AppCompatActivity{
    long id,fk_userid;
    Context context;
    ArrayList<Recipe> recipesList;
    RecyclerView rvRecipes;
    static DatabaseHelper mDatabaseHelper;
    TextView name,type,ingredients,body,recipeAllergens,recipeDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        mDatabaseHelper=new DatabaseHelper(this);

        BottomNavigationView bottomNavigationView=(BottomNavigationView)findViewById(R.id.bottom);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.home_bottom:
                        Intent intent=new Intent(DetailActivity.this, MainActivity.class);
                        startActivity(intent);
                        break;
                }
            }
        });

        getIncomingIntent();
    }

    private void getIncomingIntent(){
        if(getIntent().hasExtra("id") && getIntent().hasExtra("name") && getIntent().hasExtra("type") && getIntent().hasExtra("ingredients")
                && getIntent().hasExtra("body") && getIntent().hasExtra("allergens") && getIntent().hasExtra("date")
                && getIntent().hasExtra("fk_userid")){

            id=getIntent().getExtras().getLong("id");
            String recipeName=getIntent().getStringExtra("name");
            String recipeType=getIntent().getStringExtra("type");
            String recipeIngredients=getIntent().getStringExtra("ingredients");
            String recipeBody=getIntent().getStringExtra("body");
            String allergens=getIntent().getStringExtra("allergens");
            String date=getIntent().getStringExtra("date");
            fk_userid=getIntent().getExtras().getLong("fk_userid");

            setRecipeText(id,recipeName,recipeType,recipeIngredients,recipeBody,allergens,date,fk_userid);
        }
    }

    private void setRecipeText(long id, String recipeName,String recipeType,String recipeIngredients, String recipeBody, String allergens, String date, long fk_userid) {
        name = (TextView) findViewById(R.id.tv_display_name);
        name.setText(recipeName);

        type = (TextView) findViewById(R.id.tv_display_recipeType);
        type.setText(recipeType);

        ingredients = (TextView) findViewById(R.id.tv_display_ingredients);
        ingredients.setText(recipeIngredients);

        body = (TextView) findViewById(R.id.tv_display_recipeBody);
        body.setText(recipeBody);

        recipeAllergens = (TextView) findViewById(R.id.tv_display_allergens);
        recipeAllergens.setText(allergens);

        recipeDate = (TextView) findViewById(R.id.tv_display_date);
        recipeDate.setText(date);
    }

    public void deleteRecipe(View view) {
        RecipeActivity.mDatabaseHelper.deleteDataNew(id);
        startActivity(new Intent(DetailActivity.this, RecipeActivity.class));
        finish();
    }

    public void editRecipe(View view) {
        Intent intent=new Intent(DetailActivity.this, EditActivity.class);
        intent.putExtra("id",id);

        String getName=name.getText().toString();
        intent.putExtra("name",getName);

        String getType=type.getText().toString();
        intent.putExtra("type",getType);

        String getIngredients=ingredients.getText().toString();
        intent.putExtra("ingredients",getIngredients);

        String getBody=body.getText().toString();
        intent.putExtra("body",getBody);

        String getAllergens=recipeAllergens.getText().toString();
        intent.putExtra("allergens",getAllergens);

        String getDate=recipeDate.getText().toString();
        intent.putExtra("date",getDate);

         startActivity(intent);
    }

}
