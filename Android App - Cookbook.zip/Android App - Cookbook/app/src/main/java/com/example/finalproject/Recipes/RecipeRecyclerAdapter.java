package com.example.finalproject.Recipes;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.R;

import java.util.ArrayList;

public class RecipeRecyclerAdapter extends RecyclerView.Adapter<RecipeRecyclerAdapter.ViewHolder> {

   Context context;
   ArrayList<Recipe> recipesList;
   RecyclerView rvRecipes;
   final View.OnClickListener onClickListener=new MyOnClickListener();

   public static class ViewHolder extends RecyclerView.ViewHolder{

       TextView setName,setType,setDate;


       public ViewHolder(@NonNull View itemView) {
           super(itemView);
           setName = (TextView) itemView.findViewById(R.id.recipeNameSet);
           setType = (TextView) itemView.findViewById(R.id.recipeTypeSet);
           setDate = (TextView) itemView.findViewById(R.id.recipeDateSet);

       }
   }

   public RecipeRecyclerAdapter(Context context, ArrayList<Recipe> recipesList, RecyclerView rvRecipes)
   {
       this.context=context;
       this.recipesList=recipesList;
       this.rvRecipes=rvRecipes;
   }

   @NonNull
    @Override
    public RecipeRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       LayoutInflater inflater=LayoutInflater.from(context);
       View view=inflater.inflate(R.layout.recipes_list,parent,false);
       view.setOnClickListener(onClickListener);
       ViewHolder viewHolder=new ViewHolder(view);
       return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecipeRecyclerAdapter.ViewHolder holder, int position) {
        Recipe recipe=recipesList.get(position);
        holder.setName.setText(recipe.getrName());
        holder.setType.setText(recipe.getrType());
        holder.setDate.setText(recipe.getDate());
    }

    @Override
    public int getItemCount() {
        return recipesList.size();
    }


    private class MyOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            int itemPosition=rvRecipes.getChildAdapterPosition(v);
            String item=recipesList.get(itemPosition).getrName();
            Toast.makeText(context,item, Toast.LENGTH_SHORT).show();

            Intent intent=new Intent(context, DetailActivity.class);
            intent.putExtra("name", recipesList.get(itemPosition).getrName());
            intent.putExtra("type", recipesList.get(itemPosition).getrType());
            intent.putExtra("ingredients", recipesList.get(itemPosition).getrIngredients());
            intent.putExtra("body", recipesList.get(itemPosition).getRecipe());
            intent.putExtra("allergens", recipesList.get(itemPosition).getAllergens());
            intent.putExtra("date", recipesList.get(itemPosition).getDate());
            intent.putExtra("id", recipesList.get(itemPosition).getId());
            intent.putExtra("fk_userid", recipesList.get(itemPosition).getFk_userid());


            context.startActivity(intent);
        }
    }


}
