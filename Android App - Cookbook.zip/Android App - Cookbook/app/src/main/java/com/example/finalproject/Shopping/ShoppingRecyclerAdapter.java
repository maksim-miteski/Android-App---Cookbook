package com.example.finalproject.Shopping;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.R;

import java.util.ArrayList;

public class ShoppingRecyclerAdapter extends RecyclerView.Adapter<ShoppingRecyclerAdapter.ViewHolder> {

    Context context;
    ArrayList<ShoppingList> shoppingList;
    RecyclerView rvShopping;
    final View.OnClickListener onClickListener=new ShoppingRecyclerAdapter.MyOnClickListener();

    public static class ViewHolder extends RecyclerView.ViewHolder{

        TextView setName,setDate;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            setName = (TextView) itemView.findViewById(R.id.tv_list_NameSet);
            setDate = (TextView) itemView.findViewById(R.id.tv_list_dateSet);
        }
    }
    public ShoppingRecyclerAdapter(Context context, ArrayList<ShoppingList> shoppingList, RecyclerView rvShopping)
    {
        this.context=context;
        this.shoppingList=shoppingList;
        this.rvShopping=rvShopping;
    }

    @NonNull
    @Override
    public ShoppingRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View view=inflater.inflate(R.layout.shopping_list,parent,false);
        view.setOnClickListener(onClickListener);
        ShoppingRecyclerAdapter.ViewHolder viewHolder=new ShoppingRecyclerAdapter.ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ShoppingList shopping_list=shoppingList.get(position);
        holder.setName.setText(shopping_list.getsName());
        holder.setDate.setText(shopping_list.getsDate());

    }

    @Override
    public int getItemCount() {
        return shoppingList.size();
    }


    private class MyOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            int itemPosition=rvShopping.getChildAdapterPosition(v);
            String item=shoppingList.get(itemPosition).getsName();
            Toast.makeText(context,item, Toast.LENGTH_SHORT).show();

            Intent intent=new Intent(context, ShoppingDetailActivity.class);
            intent.putExtra("name", shoppingList.get(itemPosition).getsName());
            intent.putExtra("shopping_list", shoppingList.get(itemPosition).getsList());
            intent.putExtra("date", shoppingList.get(itemPosition).getsDate());
            intent.putExtra("id", shoppingList.get(itemPosition).getId());

            context.startActivity(intent);
        }
    }

}
