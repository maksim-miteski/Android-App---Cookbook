package com.example.finalproject.Recipes;

import android.widget.ImageView;

public class Recipe {

    long id, fk_userid;
    String rName,rType,rIngredients,recipe,allergens,date;

    public Recipe(String rName, String rType, String rIngredients, String recipe, String allergens, String date, long id,long fk_userid)
    {
        this.rName=rName;
        this.rType=rType;
        this.rIngredients=rIngredients;
        this.recipe=recipe;
        this.allergens=allergens;
        this.date=date;
        this.id=id;
        this.fk_userid=fk_userid;
    }

    public long getFk_userid() {
        return fk_userid;
    }

    public void setFk_userid(long fk_userid) {
        this.fk_userid = fk_userid;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getrName() {
        return rName;
    }

    public void setrName(String rName) {
        this.rName = rName;
    }

    public String getrType() {
        return rType;
    }

    public void setrType(String rType) {
        this.rType = rType;
    }

    public String getrIngredients() {
        return rIngredients;
    }

    public void setrIngredients(String rIngredients) {
        this.rIngredients = rIngredients;
    }

    public String getRecipe() {
        return recipe;
    }

    public void setRecipe(String recipe) {
        this.recipe = recipe;
    }

    public String getAllergens() {
        return allergens;
    }

    public void setAllergens(String allergens) {
        this.allergens = allergens;
    }

}
