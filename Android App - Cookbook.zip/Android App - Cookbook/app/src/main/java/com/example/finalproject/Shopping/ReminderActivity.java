package com.example.finalproject.Shopping;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.finalproject.Activities.MainActivity;
import com.example.finalproject.R;
import com.example.finalproject.Register.userProfile;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Calendar;

public class ReminderActivity extends AppCompatActivity implements View.OnClickListener {

    int notificationId=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);

        findViewById(R.id.btn_set).setOnClickListener(this);
        findViewById(R.id.btn_cancel).setOnClickListener(this);


        BottomNavigationView bottomNavigationView=(BottomNavigationView)findViewById(R.id.bottom);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.home_bottom:
                        Intent intent=new Intent(ReminderActivity.this, MainActivity.class);
                        startActivity(intent);
                        break;
                }
            }
        });
    }

    @Override
    public void onClick(View view) {
        EditText reminderName = findViewById(R.id.et_reminder_name);
        TimePicker timePicker = findViewById(R.id.time_picker);
        Intent intent = new Intent(ReminderActivity.this, AlarmReceiver.class);
        intent.putExtra("notificationId", notificationId);
        intent.putExtra("todo", reminderName.getText().toString());

        PendingIntent alarmIntent = PendingIntent.getBroadcast(ReminderActivity.this, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        AlarmManager alarm = (AlarmManager) getSystemService(ALARM_SERVICE);

          switch (view.getId()) {
            case R.id.btn_set:
                int hour = timePicker.getCurrentHour();
                int minute = timePicker.getCurrentMinute();

                Calendar startTime = Calendar.getInstance();
                startTime.set(Calendar.HOUR_OF_DAY, hour);
                startTime.set(Calendar.MINUTE, minute);
                startTime.set(Calendar.SECOND, 0);

                long alarmStartTime = startTime.getTimeInMillis();
                alarm.set(AlarmManager.RTC_WAKEUP, alarmStartTime, alarmIntent);
                Intent intent2 = new Intent(ReminderActivity.this, CreateShoppingListActivity.class);
                startActivity(intent2);
                Toast.makeText(this,"Reminder is Set!", Toast.LENGTH_SHORT).show();
                break;

            case R.id.btn_cancel:
                alarm.cancel(alarmIntent);
                Intent intent3 = new Intent(ReminderActivity.this, CreateShoppingListActivity.class);
                startActivity(intent3);
                Toast.makeText(this,"Canceled!", Toast.LENGTH_SHORT).show();
                break;

        }
    }
}