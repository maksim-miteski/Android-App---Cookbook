package com.example.finalproject.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.widget.Toolbar;

import com.example.finalproject.R;
import com.example.finalproject.Recipes.AddNewActivity;
import com.example.finalproject.Recipes.RecipeActivity;
import com.example.finalproject.Register.RegisterActivity;
import com.example.finalproject.Register.SessionManager;
import com.example.finalproject.Register.loginActivity;
import com.example.finalproject.Register.userProfile;
import com.example.finalproject.Shopping.CreateShoppingListActivity;
import com.example.finalproject.Shopping.ShoppingListActivity;
import com.google.android.material.navigation.NavigationView;

@SuppressWarnings("unchecked")
public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    Toolbar toolbar;
    NavigationView navigationView;
    SessionManager sessionManager;
    loginActivity LoginActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //-----------MENU--------
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        toolbar = findViewById(R.id.toolbar);
        navigationView = findViewById(R.id.navigation_view);
        sessionManager=new SessionManager(getApplicationContext());

        navigationView.setNavigationItemSelectedListener(this);
        getSupportFragmentManager().beginTransaction().replace(R.id.framelayout1, new HomeFragment());

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_draw_open, R.string.navigation_draw_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.framelayout1, new HomeFragment()).commit();
            navigationView.setCheckedItem(R.id.home_item);
        }
        //----------MENU-END----
        hideMenu();
    }

 @Override
    public boolean onCreateOptionsMenu(Menu menu){
        //super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    private void hideMenu()
    {
        Menu nav_Menu = navigationView.getMenu();
        if(sessionManager.getLogin()==true) {
            nav_Menu.findItem(R.id.register_item).setVisible(false);
            nav_Menu.findItem(R.id.login_item).setVisible(false);
        }else{
            nav_Menu.findItem(R.id.user_item).setVisible(false);
            nav_Menu.findItem(R.id.recipe_item).setVisible(false);
            nav_Menu.findItem(R.id.addnew_item).setVisible(false);
            nav_Menu.findItem(R.id.shopping_item).setVisible(false);
            nav_Menu.findItem(R.id.shoppingList_item).setVisible(false);
        }
    }

    //Enabling all the views when they are selected in the drawerMenuLayout.
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.home_item:
                getSupportFragmentManager().beginTransaction().replace(R.id.framelayout1, new HomeFragment()).commit();
                break;

           case R.id.user_item:
                Intent intentProfile = new Intent(this, userProfile.class);
                startActivity(intentProfile);
                break;

            case R.id.register_item:
                Intent intentRegister = new Intent(this, RegisterActivity.class);
                startActivity(intentRegister);
                break;

            case R.id.login_item:
                Intent intentIn = new Intent(this, loginActivity.class);
                startActivity(intentIn);
                break;

            case R.id.addnew_item:
                Intent intentNew = new Intent(this, AddNewActivity.class);
                startActivity(intentNew);
                break;

            case R.id.inspired_item:
                Intent inspired = new Intent(this, InspiredActivity.class);
                startActivity(inspired);
                break;

            case R.id.recipe_item:
                Intent intentRecipe = new Intent(this, RecipeActivity.class);
                startActivity(intentRecipe);
                break;

            case R.id.shopping_item:
                Intent intentShopping = new Intent(this, CreateShoppingListActivity.class);
                startActivity(intentShopping);
                break;

            case R.id.shoppingList_item:
                Intent intentShoppingList = new Intent(this, ShoppingListActivity.class);
                startActivity(intentShoppingList);
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
    }