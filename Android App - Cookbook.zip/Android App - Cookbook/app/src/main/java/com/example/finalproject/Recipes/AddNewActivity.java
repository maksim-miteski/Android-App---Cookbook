package com.example.finalproject.Recipes;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.finalproject.Activities.MainActivity;
import com.example.finalproject.Database.DatabaseHelper;
import com.example.finalproject.R;
import com.example.finalproject.Register.SessionManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Calendar;

public class AddNewActivity extends AppCompatActivity{

     TextView nameLabel;
     EditText editName;
     TextView selectionLabel;
     Spinner  selectionSpin, selectImage;
     TextView bodyLabel;
     EditText bodyEditText;
     TextView ingredientsLabel;
     EditText addIngredients;
    TextView allergensLabel;
    EditText addAllergens;
     Button addNewSave;
     ImageView customImage;
     long id;;

     //DATABASE VARIABLES
    DatabaseHelper mDatabaseHelper;

    TextView chooseDate, setDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addnewrecipe);

        nameLabel=(TextView)findViewById(R.id.recipeName);
        editName=(EditText)findViewById(R.id.EditTextName);
        selectionLabel=(TextView)findViewById(R.id.recipeSelectionLabel);
        selectionSpin=(Spinner)findViewById(R.id.SpinnerSelectionType);
        bodyLabel=(TextView)findViewById(R.id.recipeBodyLabel);
        bodyEditText=(EditText)findViewById(R.id.EditTextBody);
        addNewSave=(Button)findViewById(R.id.btn_addNewRecipe);
        ingredientsLabel=(TextView)findViewById(R.id.ingredientsLabel);
        addIngredients=(EditText)findViewById(R.id.et_ingredients);
//        selectImage=(Spinner)findViewById(R.id.SpinnerSelectImage);
//        customImage=(ImageView)findViewById(R.id.addCustomImg);
        allergensLabel=(TextView)findViewById(R.id.allergens_label);
        addAllergens=(EditText)findViewById(R.id.EditTextAllergens);

        mDatabaseHelper=new DatabaseHelper(this);

        BottomNavigationView bottomNavigationView=(BottomNavigationView)findViewById(R.id.bottom);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.home_bottom:
                        Intent intent=new Intent(AddNewActivity.this, MainActivity.class);
                        startActivity(intent);
                        break;
                }
            }
        });

        chooseDate=(TextView)findViewById(R.id.chooseDay);
        setDate=(TextView) findViewById(R.id.setDay);
        setDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal=Calendar.getInstance();
                int year=cal.get(Calendar.YEAR);
                int month=cal.get(Calendar.MONDAY);
                int day=cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog=new DatePickerDialog(AddNewActivity.this,
                        android.R.style.Widget_Holo,
                        mDateSetListener, year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                dialog.show();
            }
        });

        mDateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month=month+1;
                String date=month + "/" + dayOfMonth + "/" + year;
                setDate.setText(date);
            }
        };


//        final String str[]={"Choose Image","Pasta","Cake","Baking","Drink","Pie","Soup","Salad","Special Diet"};
//        ArrayAdapter arrayAdapter=new ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line,str);
//        selectImage.setAdapter(arrayAdapter);
//        selectImage.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
//                if(str[0].equals(selectImage.getItemAtPosition(i).toString())){
//                    customImage.setImageResource(R.drawable.ic_customimg);
//                } else if(str[1].equals(selectImage.getItemAtPosition(i).toString())){
//                    customImage.setImageResource(R.drawable.spaguetti);
//                }else if(str[2].equals(selectImage.getItemAtPosition(i).toString())){
//                    customImage.setImageResource(R.drawable.cake);
//                }else if(str[3].equals(selectImage.getItemAtPosition(i).toString())){
//                    customImage.setImageResource(R.drawable.baking);
//                }else if(str[4].equals(selectImage.getItemAtPosition(i).toString())){
//                    customImage.setImageResource(R.drawable.drink);
//                }else if(str[5].equals(selectImage.getItemAtPosition(i).toString())){
//                    customImage.setImageResource(R.drawable.pie);
//                }else if(str[6].equals(selectImage.getItemAtPosition(i).toString())){
//                    customImage.setImageResource(R.drawable.soup);
//                }else if(str[7].equals(selectImage.getItemAtPosition(i).toString())){
//                    customImage.setImageResource(R.drawable.salad);
//                }else if(str[8].equals(selectImage.getItemAtPosition(i).toString())){
//                    customImage.setImageResource(R.drawable.pyramid);
//                }
//            }
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//            }
//        });

        addNewSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameEntry=editName.getText().toString();
                String selectionEntry=selectionSpin.getSelectedItem().toString();
                String ingredientsEntry=addIngredients.getText().toString();
                String recipeEntry=bodyEditText.getText().toString();
                String allergensEntry=addAllergens.getText().toString();
                String dateEntry=setDate.getText().toString();
                SessionManager sessionManager=new SessionManager(AddNewActivity.this);
                long fk_userid=sessionManager.getAuthUserId();

                AddData(nameEntry,selectionEntry,ingredientsEntry,recipeEntry,allergensEntry,dateEntry,id,fk_userid);
                Intent intent=new Intent(AddNewActivity.this, RecipeActivity.class);
                startActivity(intent);
            }
        });
    }

    //DATABASE METHODS

    public void AddData(String name, String type, String ingredients, String body, String allergens, String dateEntry, long id, long fk_userid){

        boolean insertData=mDatabaseHelper.addData(name,type,ingredients,body,allergens, dateEntry,id, fk_userid);
        if(insertData == true){
            toastMessage("Data has been successfully inserted!");
        }else{
            toastMessage("Something went wrong!");
        }
    }

    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }


}