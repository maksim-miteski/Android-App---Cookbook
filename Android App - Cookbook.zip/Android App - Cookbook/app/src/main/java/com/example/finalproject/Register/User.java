package com.example.finalproject.Register;

import java.util.ArrayList;

public class User {
    long id;
    String username,password;

    public User(String username, String password, long id)
    {
        this.username=username;
        this.password=password;
        this.id=id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


}
