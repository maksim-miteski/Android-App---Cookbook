package com.example.finalproject.Register;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.finalproject.Activities.HomeFragment;
import com.example.finalproject.Activities.MainActivity;
import com.example.finalproject.R;
import com.example.finalproject.Shopping.ShoppingListActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class userProfile extends AppCompatActivity {

    TextView username,name,age;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        username=(TextView)findViewById(R.id.display_username);
//        name=(TextView)findViewById(R.id.display_name);
//        age=(TextView)findViewById(R.id.display_age);
        sessionManager=new SessionManager(getApplicationContext());

        String sUsername=sessionManager.getUsername();
        username.setText(sUsername);
//        String sName=sessionManager.getuName();
//        name.setText(sName);
//        String sAge=sessionManager.getAge();
//        age.setText(sAge);

        BottomNavigationView bottomNavigationView=(BottomNavigationView)findViewById(R.id.bottom);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.home_bottom:
                        Intent intent=new Intent(userProfile.this, MainActivity.class);
                        startActivity(intent);
                        break;
                }
            }
        });
    }

    public void logOut(View view) {
        AlertDialog.Builder builder=new AlertDialog.Builder(view.getContext());
        builder.setTitle("Log out");
        builder.setMessage("Are you sure you want to Log Out?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                sessionManager.setUsername("");
//                sessionManager.setuName("");
//                sessionManager.setAge("");
                sessionManager.setLogin(false);
                sessionManager.removeAuthUserId();

                startActivity(new Intent(userProfile.this, loginActivity.class));
                finish();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();
    }
}